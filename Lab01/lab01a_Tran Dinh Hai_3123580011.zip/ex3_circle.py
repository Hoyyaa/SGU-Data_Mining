r = float(input())
print("Enter r = ")
cv = 2*3.14*r
dt = 3.14*r*r
print('Chu vi hình tròn là: ', cv)
print("Diện tích hình tròn là: ", dt)