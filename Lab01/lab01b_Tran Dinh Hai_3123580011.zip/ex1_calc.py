print("Calculator Basic")
a = int(input("Mời bạn nhập số a: "))
b = int(input("Mời bạn nhập số b: "))
c = a + b
print("c = %d + %d = %d" % (a, b, c))